#!/bin/bash
# CYBER KALKAN v1.0 — KURULUM
set -e
[ "$EUID" -ne 0 ] && { echo "root gerekli: sudo bash kurulum.sh"; exit 1; }
D=$(cd "$(dirname "$0")" && pwd)
echo "═══ CYBER KALKAN v1.0 kuruluyor ═══"

apt-get update -qq 2>/dev/null || true
apt-get install -y -qq python3 nftables sqlite3 nginx php-fpm 2>/dev/null || true

mkdir -p /var/www/kalkan-panel /opt/siber-kalkan/MOTOR /opt/siber-kalkan/VERI /opt/siber-kalkan/LOG
cp -rf $D/panel/* /var/www/kalkan-panel/
cp -f  $D/motor/*.py /opt/siber-kalkan/MOTOR/
# WAF motoru + kok dosyalar
cp -f /opt/siber-kalkan/waf.php "$P/" 2>/dev/null
cp -f /opt/siber-kalkan/waf-router.php "$P/" 2>/dev/null
mkdir -p "$P/firewall" 2>/dev/null
cp -f /etc/nftables.d/kilic.nft "$P/firewall/" 2>/dev/null
cp -f /opt/siber-kalkan/MOTOR/kalkan_fw_yukle.py "$P/firewall/" 2>/dev/null

cp -f  $D/veri/*.json /opt/siber-kalkan/VERI/ 2>/dev/null || true
cp -f  $D/servis/*.service /etc/systemd/system/ 2>/dev/null || true

chown -R www-data:www-data /var/www/kalkan-panel
find /opt/siber-kalkan -type d -exec chmod 755 {} \;
find /var/www/kalkan-panel -type f -exec chmod 644 {} \;

systemctl daemon-reload
systemctl enable --now kalkan-motor 2>/dev/null || true
systemctl enable --now kalkan-panel 2>/dev/null || true
systemctl restart nginx 2>/dev/null || true

echo ""
echo "═══ KURULUM TAMAM ═══"
IP=$(hostname -I | awk '{print $1}')
echo "  Panel  : http://$IP:8890/"
echo "  Kullanıcı: admin"
echo "  Şifre    : (ilk girişte belirleyin)"
echo ""
echo "  Durum: systemctl status kalkan-motor"
