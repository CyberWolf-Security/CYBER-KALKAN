# CYBER KALKAN — Kalıcı Firewall
    cp kilic.nft /etc/nftables.d/kilic.nft
    cp kalkan_fw_yukle.py /opt/siber-kalkan/MOTOR/
    cp kalkan-fw-yukle.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable --now nftables kalkan-fw-yukle.service
Doğrulama: nft list set inet kilic kara
